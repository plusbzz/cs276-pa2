#!/usr/bin/env sh

# ./buildmodels.sh [extra] <training corpus dir> <training edit1s file>

python models.py $1 $2 $3
