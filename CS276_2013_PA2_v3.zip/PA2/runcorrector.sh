#!/usr/bin/env sh

# ./corrector.sh <uniform | empirical | extra > <queries file>

python corrector.py $1 $2
